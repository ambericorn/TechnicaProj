public class GuiImplementation {
	public static void main(String[] args) {
		MainMenu mainMenu = new MainMenu();
		mainMenu.setVisible(true);
	}
}